const { createContext } = require("react");

const UserContext= createContext(null);
export default UserContext;