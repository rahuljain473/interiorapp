var AdminHomepage=()=>
{
	return(
    <>
	<div className="login">
		<div className="container">
			<h2>Welcome Admin</h2>	
		</div>
	</div>
    </>
	)
}
export default AdminHomepage;