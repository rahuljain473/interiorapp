var Thanks=()=>
{
	return(
    <>
	
	<div className="login">
		<div className="container">
			<h2>Thanks for signing up. Please login now</h2>	
		</div>
	</div>
    </>
	)
}
export default Thanks;